# my_own_namespace.yandex_cloud_elk

Custom Ansible collection for Netology MNT homework.

## Contents

- Module: `my_own_module` — creates text files with idempotency
- Role: `create_file` — wrapper role with default parameters

## Usage

```yaml
- hosts: localhost
  tasks:
    - name: Create file
      my_own_namespace.yandex_cloud_elk.my_own_module:
        path: /tmp/test.txt
        content: "Hello"

